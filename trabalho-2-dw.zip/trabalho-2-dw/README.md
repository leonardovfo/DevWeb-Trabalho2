# dev-web-trabalho-2
<p>
Trabalho de desenvolvimento Web implementando a configuração do cognito AWS
</p>
<p> Alunos: </p> 
<p> Kevin Justus Piotrowski  RA:18203926 </p>
<p> Leonardo Vicente Ferreira Oliveira RA:17242326 </p>
<p> Mayara Lovatto Lopes RA:19008226 </p>
