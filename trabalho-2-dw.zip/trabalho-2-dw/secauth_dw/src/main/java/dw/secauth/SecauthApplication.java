package dw.secauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecauthApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecauthApplication.class, args);
	}

}
