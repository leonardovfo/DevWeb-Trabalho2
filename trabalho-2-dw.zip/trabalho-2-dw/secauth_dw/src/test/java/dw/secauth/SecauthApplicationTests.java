package dw.secauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecauthApplicationTests {

	@Test
	void contextLoads() {
	}

}
